# Aksara Jawa > 2023-01-03 12:26pm
https://universe.roboflow.com/thesis-8s8yg/aksara-jawa-wfoyh

Provided by a Roboflow user
License: CC BY 4.0

